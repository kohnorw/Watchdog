#!/bin/bash
set -e

echo "🐕 Building Watchdog..."

docker stop watchdog 2>/dev/null && echo "Stopped old container" || true
docker rm watchdog   2>/dev/null && echo "Removed old container" || true
docker rmi watchdog  2>/dev/null && echo "Removed old image" || true

docker build --build-arg CACHEBUST=$(date +%s) -t watchdog .

docker run -d \
  --name watchdog \
  --restart unless-stopped \
  -p 5001:5000 \
  -v /docker/watchdog/data:/data \
  watchdog

echo "✅ Watchdog running at http://$(hostname -I | awk '{print $1}'):5001"

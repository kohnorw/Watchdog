import os, sqlite3, json, time, threading, requests, re
from datetime import datetime
from flask import Flask, render_template, request, jsonify, redirect, url_for
from apscheduler.schedulers.background import BackgroundScheduler

app = Flask(__name__)
app.secret_key = os.urandom(24)
DB_PATH = "/data/watchdog.db"
CONFIG_PATH = "/data/config.json"

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    os.makedirs("/data", exist_ok=True)
    conn = get_db()
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS sonarr_shows (id INTEGER PRIMARY KEY, tvdb_id INTEGER, title TEXT, year INTEGER, updated_at TEXT);
        CREATE TABLE IF NOT EXISTS radarr_movies (id INTEGER PRIMARY KEY, tmdb_id INTEGER, title TEXT, year INTEGER, updated_at TEXT);
        CREATE TABLE IF NOT EXISTS rd_torrents (id TEXT PRIMARY KEY, filename TEXT, hash TEXT, status TEXT, bytes INTEGER, added TEXT, matched_type TEXT, matched_id INTEGER, matched_title TEXT, processed INTEGER DEFAULT 0, inserted_at TEXT);
        CREATE TABLE IF NOT EXISTS unmatched (id INTEGER PRIMARY KEY AUTOINCREMENT, rd_id TEXT UNIQUE, filename TEXT, hash TEXT, resolved INTEGER DEFAULT 0, resolved_type TEXT, resolved_arr_id INTEGER, resolved_title TEXT, inserted_at TEXT);
        CREATE TABLE IF NOT EXISTS run_log (id INTEGER PRIMARY KEY AUTOINCREMENT, started_at TEXT, finished_at TEXT, rd_count INTEGER, matched INTEGER, unmatched INTEGER, created_sonarr INTEGER, created_radarr INTEGER, reinserted INTEGER, errors TEXT);
    """)
    conn.commit(); conn.close()

def get_config():
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH) as f: return json.load(f)
    return {}

def save_config(cfg):
    os.makedirs("/data", exist_ok=True)
    with open(CONFIG_PATH, "w") as f: json.dump(cfg, f, indent=2)

def is_configured():
    cfg = get_config()
    return all(cfg.get(k) for k in ["sonarr_url","sonarr_key","radarr_url","radarr_key","rd_key","decypharr_url","decypharr_user","decypharr_pass"])

def sonarr_req(method, path, data=None):
    cfg = get_config()
    r = requests.request(method, f"{cfg['sonarr_url'].rstrip('/')}/api/v3{path}", headers={"X-Api-Key": cfg["sonarr_key"], "Content-Type": "application/json"}, json=data, timeout=15)
    r.raise_for_status(); return r.json()

def radarr_req(method, path, data=None):
    cfg = get_config()
    r = requests.request(method, f"{cfg['radarr_url'].rstrip('/')}/api/v3{path}", headers={"X-Api-Key": cfg["radarr_key"], "Content-Type": "application/json"}, json=data, timeout=15)
    r.raise_for_status(); return r.json()

def rd_get(path, params=None):
    cfg = get_config()
    r = requests.get(f"https://api.real-debrid.com/rest/1.0{path}", headers={"Authorization": f"Bearer {cfg['rd_key']}"}, params=params, timeout=15)
    r.raise_for_status(); return r.json()

def rd_post(path, data=None):
    cfg = get_config()
    r = requests.post(f"https://api.real-debrid.com/rest/1.0{path}", headers={"Authorization": f"Bearer {cfg['rd_key']}"}, data=data, timeout=15)
    r.raise_for_status(); return r.json() if r.text.strip() else {}

def decypharr_add(magnet, category):
    cfg = get_config()
    r = requests.post(f"{cfg['decypharr_url'].rstrip('/')}/api/v2/torrents/add", auth=(cfg["decypharr_user"], cfg["decypharr_pass"]), data={"urls": magnet, "category": category}, timeout=15)
    return r.status_code < 400

def tmdb_search(query, kind="tv"):
    cfg = get_config()
    if not cfg.get("tmdb_key"): return None
    ep = "search/tv" if kind == "tv" else "search/movie"
    r = requests.get(f"https://api.themoviedb.org/3/{ep}", params={"api_key": cfg["tmdb_key"], "query": query}, timeout=10)
    return r.json()["results"][0] if r.ok and r.json().get("results") else None

def tmdb_get_tvdb(tmdb_id):
    cfg = get_config()
    if not cfg.get("tmdb_key"): return None
    r = requests.get(f"https://api.themoviedb.org/3/tv/{tmdb_id}/external_ids", params={"api_key": cfg["tmdb_key"]}, timeout=10)
    return r.json().get("tvdb_id") if r.ok else None

def clean_name(name):
    name = re.sub(r'\.(mkv|mp4|avi|mov|ts)$', '', name, flags=re.I)
    name = re.sub(r'[\._]', ' ', name)
    name = re.sub(r'\b(1080p|720p|4k|2160p|bluray|webrip|webdl|web dl|hdtv|dvdrip|x264|x265|hevc|aac|dts|ac3|h264|h265|remux|proper|repack|yify|yts|rarbg|ettv|eztv|flux|ntb|psarips|hmax|dsnp|nf|amzn|hulu|atvp|s\d{2}e\d{2}|s\d{2})\b', '', name, flags=re.I)
    name = re.sub(r'\b(19|20)\d{2}\b', '', name)
    name = re.sub(r'\[.*?\]|\(.*?\)', '', name)
    return re.sub(r'\s+', ' ', name).strip()

def is_tv(filename):
    return bool(re.search(r'S\d{1,2}E\d{1,2}|S\d{1,2}\b|\bSeason\s*\d', filename, re.I))

def fuzzy_match(title, candidates):
    tl = title.lower().strip()
    best, score = None, 0
    for c in candidates:
        cl = c["title"].lower().strip()
        if cl == tl: return c, 100
        tw, cw = set(tl.split()), set(cl.split())
        if not tw or not cw: continue
        ov = len(tw & cw) / len(tw | cw) * 100
        if ov > score: score, best = ov, c
    return (best, score) if score > 45 else (None, 0)

def get_root(arr):
    try:
        folders = sonarr_req("GET", "/rootfolder") if arr == "sonarr" else radarr_req("GET", "/rootfolder")
        return folders[0]["path"] if folders else ("/tv/" if arr == "sonarr" else "/movies/")
    except: return "/tv/" if arr == "sonarr" else "/movies/"

def get_qp(arr):
    try:
        profiles = sonarr_req("GET", "/qualityprofile") if arr == "sonarr" else radarr_req("GET", "/qualityprofile")
        for p in profiles:
            if "1080" in p["name"]: return p["id"]
        return profiles[0]["id"]
    except: return 1

def create_sonarr(title, tvdb_id, year):
    try:
        return sonarr_req("POST", "/series", {"title": title, "tvdbId": int(tvdb_id), "qualityProfileId": get_qp("sonarr"), "rootFolderPath": get_root("sonarr"), "monitored": True, "addOptions": {"searchForMissingEpisodes": True}})
    except Exception as e:
        print(f"create_sonarr: {e}"); return None

def create_radarr(title, tmdb_id, year):
    try:
        return radarr_req("POST", "/movie", {"title": title, "tmdbId": int(tmdb_id), "qualityProfileId": get_qp("radarr"), "rootFolderPath": get_root("radarr"), "monitored": True, "addOptions": {"searchForMovie": True}})
    except Exception as e:
        print(f"create_radarr: {e}"); return None

def reinsert(rd_hash, category):
    try:
        magnet = f"magnet:?xt=urn:btih:{rd_hash}"
        result = rd_post("/torrents/addMagnet", {"magnet": magnet})
        new_id = result.get("id")
        if new_id:
            time.sleep(1)
            rd_post(f"/torrents/selectFiles/{new_id}", {"files": "all"})
        decypharr_add(magnet, category)
        return True
    except Exception as e:
        print(f"reinsert: {e}"); return False

def run_sync(full=True):
    if not is_configured(): return
    log = {"started_at": datetime.utcnow().isoformat(), "rd_count": 0, "matched": 0, "unmatched": 0, "created_sonarr": 0, "created_radarr": 0, "reinserted": 0, "errors": []}
    try:
        shows = sonarr_req("GET", "/series")
        movies = radarr_req("GET", "/movie")
        conn = get_db()
        conn.execute("DELETE FROM sonarr_shows")
        for s in shows: conn.execute("INSERT OR REPLACE INTO sonarr_shows VALUES (?,?,?,?,?)", (s["id"], s.get("tvdbId"), s["title"], s.get("year"), datetime.utcnow().isoformat()))
        conn.execute("DELETE FROM radarr_movies")
        for m in movies: conn.execute("INSERT OR REPLACE INTO radarr_movies VALUES (?,?,?,?,?)", (m["id"], m.get("tmdbId"), m["title"], m.get("year"), datetime.utcnow().isoformat()))
        conn.commit()

        if full:
            rd_items, page = [], 1
            while True:
                batch = rd_get("/torrents", {"page": page, "limit": 100})
                if not batch: break
                rd_items.extend(batch); page += 1
        else:
            rd_items = rd_get("/torrents", {"page": 1, "limit": 100})

        log["rd_count"] = len(rd_items)
        show_list = [{"title": s["title"], "id": s["id"]} for s in shows]
        movie_list = [{"title": m["title"], "id": m["id"]} for m in movies]

        for item in rd_items:
            rd_id, filename, rd_hash = item["id"], item.get("filename", ""), item.get("hash", "")
            existing = conn.execute("SELECT processed FROM rd_torrents WHERE id=?", (rd_id,)).fetchone()
            if existing and existing["processed"]: continue
            conn.execute("INSERT OR REPLACE INTO rd_torrents (id,filename,hash,status,bytes,added,inserted_at) VALUES (?,?,?,?,?,?,?)",
                (rd_id, filename, rd_hash, item.get("status",""), item.get("bytes",0), item.get("added",""), datetime.utcnow().isoformat()))
            clean = clean_name(filename)
            tv = is_tv(filename)
            matched, m_type, m_id, m_title, cat = False, None, None, None, None
            if tv:
                match, _ = fuzzy_match(clean, show_list)
                if match:
                    matched, m_type, m_id, m_title, cat = True, "sonarr", match["id"], match["title"], "sonarr"
                else:
                    res = tmdb_search(clean, "tv")
                    if res:
                        tvdb_id = tmdb_get_tvdb(res["id"])
                        if tvdb_id:
                            created = create_sonarr(res.get("name", clean), tvdb_id, (res.get("first_air_date") or "")[:4])
                            if created:
                                log["created_sonarr"] += 1
                                show_list.append({"title": created["title"], "id": created["id"]})
                                matched, m_type, m_id, m_title, cat = True, "sonarr", created["id"], created["title"], "sonarr"
            else:
                match, _ = fuzzy_match(clean, movie_list)
                if match:
                    matched, m_type, m_id, m_title, cat = True, "radarr", match["id"], match["title"], "radarr"
                else:
                    res = tmdb_search(clean, "movie")
                    if res:
                        created = create_radarr(res.get("title", clean), res["id"], (res.get("release_date") or "")[:4])
                        if created:
                            log["created_radarr"] += 1
                            movie_list.append({"title": created["title"], "id": created["id"]})
                            matched, m_type, m_id, m_title, cat = True, "radarr", created["id"], created["title"], "radarr"
            if matched and rd_hash:
                if reinsert(rd_hash, cat): log["reinserted"] += 1
                conn.execute("UPDATE rd_torrents SET matched_type=?,matched_id=?,matched_title=?,processed=1 WHERE id=?", (m_type, m_id, m_title, rd_id))
                log["matched"] += 1
            else:
                log["unmatched"] += 1
                conn.execute("INSERT OR IGNORE INTO unmatched (rd_id,filename,hash,inserted_at) VALUES (?,?,?,?)", (rd_id, filename, rd_hash, datetime.utcnow().isoformat()))
        conn.commit(); conn.close()
    except Exception as e:
        log["errors"].append(str(e)); print(f"Sync error: {e}")
    log["finished_at"] = datetime.utcnow().isoformat()
    conn = get_db()
    conn.execute("INSERT INTO run_log (started_at,finished_at,rd_count,matched,unmatched,created_sonarr,created_radarr,reinserted,errors) VALUES (?,?,?,?,?,?,?,?,?)",
        (log["started_at"],log["finished_at"],log["rd_count"],log["matched"],log["unmatched"],log["created_sonarr"],log["created_radarr"],log["reinserted"],json.dumps(log["errors"])))
    conn.commit(); conn.close()

@app.route("/")
def index():
    if not is_configured(): return redirect(url_for("setup"))
    conn = get_db()
    uc = conn.execute("SELECT COUNT(*) as c FROM unmatched WHERE resolved=0").fetchone()["c"]
    last_run = conn.execute("SELECT * FROM run_log ORDER BY id DESC LIMIT 1").fetchone()
    recent_runs = conn.execute("SELECT * FROM run_log ORDER BY id DESC LIMIT 5").fetchall()
    rd_c = conn.execute("SELECT COUNT(*) as c FROM rd_torrents").fetchone()["c"]
    sc = conn.execute("SELECT COUNT(*) as c FROM sonarr_shows").fetchone()["c"]
    rc = conn.execute("SELECT COUNT(*) as c FROM radarr_movies").fetchone()["c"]
    proc = conn.execute("SELECT COUNT(*) as c FROM rd_torrents WHERE processed=1").fetchone()["c"]
    conn.close()
    return render_template("index.html", unmatched_count=uc, last_run=last_run, recent_runs=recent_runs, rd_count=rd_c, sonarr_count=sc, radarr_count=rc, reinserted=proc)

@app.route("/setup", methods=["GET","POST"])
def setup():
    if request.method == "POST":
        save_config({k: request.form.get(k,"").strip() for k in ["sonarr_url","sonarr_key","radarr_url","radarr_key","rd_key","decypharr_url","decypharr_user","decypharr_pass","tmdb_key"]})
        threading.Thread(target=run_sync, args=(True,), daemon=True).start()
        return redirect(url_for("index"))
    return render_template("setup.html", cfg=get_config())

@app.route("/unmatched")
def unmatched_page():
    conn = get_db()
    items = conn.execute("SELECT * FROM unmatched WHERE resolved=0 ORDER BY inserted_at DESC").fetchall()
    shows = conn.execute("SELECT * FROM sonarr_shows ORDER BY title").fetchall()
    movies = conn.execute("SELECT * FROM radarr_movies ORDER BY title").fetchall()
    conn.close()
    return render_template("unmatched.html", items=items, shows=shows, movies=movies)

@app.route("/resolve", methods=["POST"])
def resolve():
    data = request.json
    conn = get_db()
    item = conn.execute("SELECT * FROM unmatched WHERE id=?", (data["id"],)).fetchone()
    if not item: return jsonify({"error": "not found"}), 404
    ok = reinsert(item["hash"], data["type"])
    conn.execute("UPDATE unmatched SET resolved=1,resolved_type=?,resolved_arr_id=?,resolved_title=? WHERE id=?", (data["type"],data["arr_id"],data["title"],data["id"]))
    conn.execute("UPDATE rd_torrents SET matched_type=?,matched_id=?,matched_title=?,processed=1 WHERE id=?", (data["type"],data["arr_id"],data["title"],item["rd_id"]))
    conn.commit(); conn.close()
    return jsonify({"ok": ok})

@app.route("/logs")
def logs():
    conn = get_db()
    runs = conn.execute("SELECT * FROM run_log ORDER BY id DESC LIMIT 100").fetchall()
    conn.close()
    return render_template("logs.html", runs=runs)

@app.route("/settings")
def settings():
    return render_template("setup.html", cfg=get_config(), edit=True)

@app.route("/api/run", methods=["POST"])
def manual_run():
    full = (request.json or {}).get("full", False)
    threading.Thread(target=run_sync, args=(full,), daemon=True).start()
    return jsonify({"ok": True})

@app.route("/api/status")
def api_status():
    conn = get_db()
    lr = conn.execute("SELECT * FROM run_log ORDER BY id DESC LIMIT 1").fetchone()
    uc = conn.execute("SELECT COUNT(*) as c FROM unmatched WHERE resolved=0").fetchone()["c"]
    conn.close()
    return jsonify({"last_run": dict(lr) if lr else None, "unmatched": uc})

scheduler = BackgroundScheduler()
scheduler.add_job(lambda: run_sync(False), "interval", minutes=10, id="poll")
scheduler.start()

if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=5000, debug=False)

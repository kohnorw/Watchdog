import re
from thefuzz import fuzz
from database import get_db
from clients import (get_sonarr_shows, get_radarr_movies, get_rd_torrents,
    reinsert, lookup_show, add_show, search_tmdb, add_movie, parse_filename)

THRESHOLD = 80

def normalize(t):
    return re.sub(r'\s+', ' ', re.sub(r'[^\w\s]', ' ', t.lower())).strip()

def best_match(title, items):
    best, item = 0, None
    n = normalize(title)
    for i in items:
        s = fuzz.token_sort_ratio(n, normalize(i['title']))
        if s > best:
            best, item = s, i
    return item, best

def sync_libraries():
    conn = get_db()
    shows = get_sonarr_shows()
    conn.execute('DELETE FROM sonarr_shows')
    for s in shows:
        conn.execute('INSERT OR REPLACE INTO sonarr_shows (id,tvdb_id,title,year) VALUES (?,?,?,?)',
            (s['id'], s.get('tvdbId'), s['title'], s.get('year')))
    movies = get_radarr_movies()
    conn.execute('DELETE FROM radarr_movies')
    for m in movies:
        conn.execute('INSERT OR REPLACE INTO radarr_movies (id,tmdb_id,title,year) VALUES (?,?,?,?)',
            (m['id'], m.get('tmdbId'), m['title'], m.get('year')))
    conn.commit()
    conn.close()
    return len(shows), len(movies)

def process_page(page=1):
    conn = get_db()
    matched = unmatched = 0
    errors = []
    try:
        shows = [dict(r) for r in conn.execute('SELECT * FROM sonarr_shows').fetchall()]
        movies = [dict(r) for r in conn.execute('SELECT * FROM radarr_movies').fetchall()]
        torrents = get_rd_torrents(page=page)

        for t in torrents:
            tid = t['id']
            filename = t.get('filename', '')
            thash = t.get('hash', '')

            existing = conn.execute('SELECT processed FROM rd_torrents WHERE id=?', (tid,)).fetchone()
            if existing and existing['processed']:
                continue

            conn.execute('INSERT OR REPLACE INTO rd_torrents (id,filename,hash,status,bytes,added) VALUES (?,?,?,?,?,?)',
                (tid, filename, thash, t.get('status',''), t.get('bytes',0), t.get('added','')))

            ctype, title, year = parse_filename(filename)
            if not title:
                unmatched += 1
                conn.execute('INSERT OR IGNORE INTO unmatched (rd_torrent_id,filename,suggested_type) VALUES (?,?,?)', (tid, filename, ctype))
                continue

            if ctype == 'show':
                item, score = best_match(title, shows)
                if score >= THRESHOLD and item:
                    conn.execute('UPDATE rd_torrents SET matched_type=?,matched_id=?,matched_title=?,processed=1 WHERE id=?', ('show', item['id'], item['title'], tid))
                    try: reinsert(tid, thash, 'sonarr')
                    except Exception as e: errors.append(str(e))
                    matched += 1
                else:
                    try:
                        res = lookup_show(title)
                        if not res: raise Exception(f'No TVDB result for: {title}')
                        new = add_show(res.get('tvdbId'), res.get('title', title), res.get('year', year or 0))
                        conn.execute('UPDATE rd_torrents SET matched_type=?,matched_id=?,matched_title=?,processed=1 WHERE id=?', ('show', new.get('id'), new.get('title'), tid))
                        reinsert(tid, thash, 'sonarr')
                        matched += 1
                    except Exception as e:
                        errors.append(f"{filename}: {e}")
                        unmatched += 1
                        conn.execute('INSERT OR IGNORE INTO unmatched (rd_torrent_id,filename,suggested_title,suggested_type) VALUES (?,?,?,?)', (tid, filename, title, 'show'))
            else:
                item, score = best_match(title, movies)
                if score >= THRESHOLD and item:
                    conn.execute('UPDATE rd_torrents SET matched_type=?,matched_id=?,matched_title=?,processed=1 WHERE id=?', ('movie', item['id'], item['title'], tid))
                    try: reinsert(tid, thash, 'radarr')
                    except Exception as e: errors.append(str(e))
                    matched += 1
                else:
                    try:
                        res = search_tmdb(title, year)
                        if not res: raise Exception(f'No TMDB result for: {title}')
                        yr = res.get('release_date','')[:4] or year or 0
                        new = add_movie(res['id'], res['title'], yr)
                        conn.execute('UPDATE rd_torrents SET matched_type=?,matched_id=?,matched_title=?,processed=1 WHERE id=?', ('movie', new.get('id'), new.get('title'), tid))
                        reinsert(tid, thash, 'radarr')
                        matched += 1
                    except Exception as e:
                        errors.append(f"{filename}: {e}")
                        unmatched += 1
                        conn.execute('INSERT OR IGNORE INTO unmatched (rd_torrent_id,filename,suggested_title,suggested_type) VALUES (?,?,?,?)', (tid, filename, title, 'movie'))

        conn.execute('INSERT INTO run_log (torrents_processed,matched,unmatched,errors) VALUES (?,?,?,?)',
            (len(torrents), matched, unmatched, '\n'.join(errors)))
        conn.commit()
    finally:
        conn.close()
    return matched, unmatched, errors

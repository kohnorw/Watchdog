import requests, re, base64
from database import get_setting

def sonarr_get(path):
    url = get_setting('sonarr_url','').rstrip('/') + path
    r = requests.get(url, headers={'X-Api-Key': get_setting('sonarr_api_key','')}, timeout=10)
    r.raise_for_status()
    return r.json()

def sonarr_post(path, data):
    url = get_setting('sonarr_url','').rstrip('/') + path
    r = requests.post(url, headers={'X-Api-Key': get_setting('sonarr_api_key',''), 'Content-Type':'application/json'}, json=data, timeout=10)
    r.raise_for_status()
    return r.json()

def radarr_get(path):
    url = get_setting('radarr_url','').rstrip('/') + path
    r = requests.get(url, headers={'X-Api-Key': get_setting('radarr_api_key','')}, timeout=10)
    r.raise_for_status()
    return r.json()

def radarr_post(path, data):
    url = get_setting('radarr_url','').rstrip('/') + path
    r = requests.post(url, headers={'X-Api-Key': get_setting('radarr_api_key',''), 'Content-Type':'application/json'}, json=data, timeout=10)
    r.raise_for_status()
    return r.json()

def rd(method, path, **kwargs):
    url = 'https://api.real-debrid.com/rest/1.0' + path
    r = requests.request(method, url, headers={'Authorization': f"Bearer {get_setting('rd_api_key','')}"}, timeout=15, **kwargs)
    r.raise_for_status()
    return r

def decypharr_post(magnet, category):
    url = get_setting('decypharr_url','').rstrip('/') + '/api/v2/torrents/add'
    u = get_setting('decypharr_user','admin')
    p = get_setting('decypharr_pass','admin')
    auth = base64.b64encode(f"{u}:{p}".encode()).decode()
    r = requests.post(url, headers={'Authorization': f'Basic {auth}'}, data={'urls': magnet, 'category': category}, timeout=10)
    return r.status_code == 200

def get_sonarr_shows():    return sonarr_get('/api/v3/series')
def get_sonarr_profiles(): return sonarr_get('/api/v3/qualityprofile')
def get_sonarr_folders():  return sonarr_get('/api/v3/rootfolder')
def lookup_show(title):
    r = sonarr_get(f'/api/v3/series/lookup?term={requests.utils.quote(title)}')
    return r[0] if r else None

def add_show(tvdb_id, title, year):
    return sonarr_post('/api/v3/series', {
        'tvdbId': int(tvdb_id), 'title': title, 'year': int(year or 0),
        'qualityProfileId': int(get_setting('sonarr_quality_profile', 1)),
        'rootFolderPath': get_setting('sonarr_root_folder', '/tv/'),
        'monitored': True, 'addOptions': {'searchForMissingEpisodes': True}
    })

def get_radarr_movies():    return radarr_get('/api/v3/movie')
def get_radarr_profiles():  return radarr_get('/api/v3/qualityprofile')
def get_radarr_folders():   return radarr_get('/api/v3/rootfolder')

def search_tmdb(title, year=None):
    params = {'api_key': get_setting('tmdb_api_key',''), 'query': title}
    if year: params['year'] = year
    r = requests.get('https://api.themoviedb.org/3/search/movie', params=params, timeout=10)
    r.raise_for_status()
    results = r.json().get('results', [])
    return results[0] if results else None

def add_movie(tmdb_id, title, year):
    return radarr_post('/api/v3/movie', {
        'tmdbId': int(tmdb_id), 'title': title, 'year': int(year or 0),
        'qualityProfileId': int(get_setting('radarr_quality_profile', 1)),
        'rootFolderPath': get_setting('radarr_root_folder', '/movies/'),
        'monitored': True, 'addOptions': {'searchForMovie': True}
    })

def get_rd_torrents(page=1):
    return rd('GET', '/torrents', params={'page': page, 'limit': 100}).json()

def delete_rd(tid):
    try: rd('DELETE', f'/torrents/delete/{tid}')
    except: pass

def add_rd_magnet(magnet):
    return rd('POST', '/torrents/addMagnet', data={'magnet': magnet}).json()

def select_rd_files(tid):
    try: rd('POST', f'/torrents/selectFiles/{tid}', data={'files': 'all'})
    except: pass

def reinsert(torrent_id, torrent_hash, category):
    magnet = f"magnet:?xt=urn:btih:{torrent_hash}"
    delete_rd(torrent_id)
    result = add_rd_magnet(magnet)
    new_id = result.get('id')
    if new_id:
        select_rd_files(new_id)
    decypharr_post(magnet, category)
    return new_id

def parse_filename(filename):
    tv = re.search(r'[Ss]\d{1,2}[Ee]\d{1,2}', filename)
    if tv:
        raw = filename[:tv.start()]
        title = re.sub(r'[\._\-]+', ' ', raw).strip()
        yr = re.search(r'\b(19|20)\d{2}\b', title)
        year = int(yr.group()) if yr else None
        if yr: title = title[:yr.start()].strip()
        return 'show', title.strip(), year
    name = re.sub(r'\[.*?\]|\(.*?\)', '', filename)
    name = re.sub(r'\.(mkv|mp4|avi|ts|m4v)$', '', name, flags=re.I)
    yr = re.search(r'\b(19|20)\d{2}\b', name)
    year = int(yr.group()) if yr else None
    raw = name[:yr.start()] if yr else name
    title = re.sub(r'[\._\-]+', ' ', raw).strip()
    title = re.sub(r'\b(1080p|720p|2160p|4k|bluray|web|hdtv|x264|x265|hevc|aac|dts|hdr|remux)\b.*', '', title, flags=re.I).strip()
    return 'movie', title.strip(), year

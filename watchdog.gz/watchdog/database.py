import sqlite3, os
DB_PATH = os.environ.get('DB_PATH', '/data/watchdog.db')

def get_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    conn.executescript('''
        CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT);
        CREATE TABLE IF NOT EXISTS sonarr_shows (id INTEGER PRIMARY KEY, tvdb_id INTEGER, title TEXT, year INTEGER, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS radarr_movies (id INTEGER PRIMARY KEY, tmdb_id INTEGER, title TEXT, year INTEGER, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS rd_torrents (id TEXT PRIMARY KEY, filename TEXT, hash TEXT, status TEXT, bytes INTEGER, added TEXT, matched_type TEXT, matched_id INTEGER, matched_title TEXT, processed INTEGER DEFAULT 0, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS unmatched (id INTEGER PRIMARY KEY AUTOINCREMENT, rd_torrent_id TEXT, filename TEXT, suggested_title TEXT, suggested_type TEXT, manually_matched INTEGER DEFAULT 0, matched_type TEXT, matched_id INTEGER, matched_title TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS run_log (id INTEGER PRIMARY KEY AUTOINCREMENT, run_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, torrents_processed INTEGER DEFAULT 0, matched INTEGER DEFAULT 0, unmatched INTEGER DEFAULT 0, errors TEXT);
    ''')
    conn.commit()
    conn.close()

def get_setting(key, default=None):
    try:
        conn = get_db()
        row = conn.execute('SELECT value FROM settings WHERE key=?', (key,)).fetchone()
        conn.close()
        return row['value'] if row else default
    except:
        return default

def set_setting(key, value):
    conn = get_db()
    conn.execute('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)', (key, value))
    conn.commit()
    conn.close()

def get_all_settings():
    try:
        conn = get_db()
        rows = conn.execute('SELECT key, value FROM settings').fetchall()
        conn.close()
        return {r['key']: r['value'] for r in rows}
    except:
        return {}

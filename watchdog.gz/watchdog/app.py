from flask import Flask, render_template, request, jsonify, redirect, url_for
from apscheduler.schedulers.background import BackgroundScheduler
import threading
from database import init_db, get_setting, set_setting, get_all_settings, get_db
from clients import (get_sonarr_profiles, get_sonarr_folders, get_radarr_profiles,
    get_radarr_folders, lookup_show, add_show, search_tmdb, add_movie, reinsert)
from sync import sync_libraries, process_page

app = Flask(__name__)
scheduler = BackgroundScheduler(daemon=True)
lock = threading.Lock()

REQUIRED = ['sonarr_url','sonarr_api_key','radarr_url','radarr_api_key','rd_api_key','decypharr_url','tmdb_api_key']

def configured():
    return all(get_setting(k) for k in REQUIRED)

def run_sync(full=False):
    if lock.locked(): return
    with lock:
        try:
            sync_libraries()
            process_page(page=1)
        except Exception as e:
            print(f'Sync error: {e}')

# ── Routes ──────────────────────────────────────────────

@app.route('/')
def index():
    if not configured():
        return redirect(url_for('setup'))
    conn = get_db()
    stats = {
        'shows':      conn.execute('SELECT COUNT(*) as c FROM sonarr_shows').fetchone()['c'],
        'movies':     conn.execute('SELECT COUNT(*) as c FROM radarr_movies').fetchone()['c'],
        'rd_total':   conn.execute('SELECT COUNT(*) as c FROM rd_torrents').fetchone()['c'],
        'matched':    conn.execute('SELECT COUNT(*) as c FROM rd_torrents WHERE processed=1').fetchone()['c'],
        'unmatched':  conn.execute('SELECT COUNT(*) as c FROM unmatched WHERE manually_matched=0').fetchone()['c'],
    }
    runs   = conn.execute('SELECT * FROM run_log ORDER BY run_at DESC LIMIT 6').fetchall()
    recent = conn.execute('SELECT * FROM rd_torrents WHERE processed=1 ORDER BY updated_at DESC LIMIT 25').fetchall()
    conn.close()
    return render_template('dashboard.html', stats=stats, runs=runs, recent=recent)

@app.route('/matched')
def matched():
    conn = get_db()
    items = conn.execute('SELECT * FROM rd_torrents WHERE processed=1 ORDER BY updated_at DESC').fetchall()
    conn.close()
    return render_template('matched.html', items=items)

@app.route('/unmatched')
def unmatched():
    conn = get_db()
    items = conn.execute('SELECT * FROM unmatched WHERE manually_matched=0 ORDER BY created_at DESC').fetchall()
    conn.close()
    return render_template('unmatched.html', items=items)

@app.route('/setup', methods=['GET','POST'])
def setup():
    error = None
    profiles = {}
    folders = {}
    settings = get_all_settings()

    if request.method == 'POST':
        action = request.form.get('action','save')
        keys = ['sonarr_url','sonarr_api_key','radarr_url','radarr_api_key',
                'rd_api_key','decypharr_url','decypharr_user','decypharr_pass','tmdb_api_key']
        for k in keys:
            if request.form.get(k):
                set_setting(k, request.form.get(k))
        settings = get_all_settings()

        if action == 'test':
            try:
                profiles['sonarr'] = get_sonarr_profiles()
                profiles['radarr'] = get_radarr_profiles()
                folders['sonarr']  = get_sonarr_folders()
                folders['radarr']  = get_radarr_folders()
            except Exception as e:
                error = str(e)
        else:
            for k in ['sonarr_quality_profile','sonarr_root_folder','radarr_quality_profile','radarr_root_folder']:
                if request.form.get(k):
                    set_setting(k, request.form.get(k))
            threading.Thread(target=run_sync, kwargs={'full':True}, daemon=True).start()
            return redirect(url_for('index'))

    return render_template('setup.html', error=error, settings=settings, profiles=profiles, folders=folders)

@app.route('/unmatched/search')
def unmatched_search():
    title = request.args.get('title','')
    ctype = request.args.get('type','movie')
    try:
        if ctype == 'movie':
            r = search_tmdb(title)
            if r:
                return jsonify([{'id': r['id'], 'title': r['title'], 'year': r.get('release_date','')[:4], 'type':'movie'}])
        else:
            r = lookup_show(title)
            if r:
                return jsonify([{'id': r.get('tvdbId'), 'title': r.get('title'), 'year': r.get('year'), 'type':'show'}])
        return jsonify([])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/unmatched/match', methods=['POST'])
def do_match():
    d = request.json
    uid = d['unmatched_id']
    ctype = d['type']
    ext_id = d['external_id']
    title = d['title']
    year = d.get('year', 0)
    conn = get_db()
    try:
        item = conn.execute('SELECT * FROM unmatched WHERE id=?', (uid,)).fetchone()
        if ctype == 'movie':
            new = add_movie(ext_id, title, year)
            mid = new.get('id')
            cat = 'radarr'
        else:
            new = add_show(ext_id, title, year)
            mid = new.get('id')
            cat = 'sonarr'
        rd = conn.execute('SELECT * FROM rd_torrents WHERE id=?', (item['rd_torrent_id'],)).fetchone()
        if rd and rd['hash']:
            reinsert(rd['id'], rd['hash'], cat)
        conn.execute('UPDATE unmatched SET manually_matched=1,matched_type=?,matched_id=?,matched_title=? WHERE id=?', (ctype,mid,title,uid))
        conn.execute('UPDATE rd_torrents SET matched_type=?,matched_id=?,matched_title=?,processed=1 WHERE id=?', (ctype,mid,title,item['rd_torrent_id']))
        conn.commit()
        return jsonify({'success': True})
    except Exception as e:
        conn.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        conn.close()

@app.route('/api/sync', methods=['POST'])
def api_sync():
    threading.Thread(target=run_sync, kwargs={'full':True}, daemon=True).start()
    return jsonify({'status':'started'})

@app.route('/api/status')
def api_status():
    conn = get_db()
    last = conn.execute('SELECT run_at FROM run_log ORDER BY run_at DESC LIMIT 1').fetchone()
    stats = {
        'shows':     conn.execute('SELECT COUNT(*) as c FROM sonarr_shows').fetchone()['c'],
        'movies':    conn.execute('SELECT COUNT(*) as c FROM radarr_movies').fetchone()['c'],
        'matched':   conn.execute('SELECT COUNT(*) as c FROM rd_torrents WHERE processed=1').fetchone()['c'],
        'unmatched': conn.execute('SELECT COUNT(*) as c FROM unmatched WHERE manually_matched=0').fetchone()['c'],
        'last_run':  last['run_at'] if last else None,
    }
    conn.close()
    return jsonify(stats)

if __name__ == '__main__':
    init_db()
    scheduler.add_job(run_sync, 'interval', minutes=10, id='poll')
    scheduler.start()
    app.run(host='0.0.0.0', port=5000)
